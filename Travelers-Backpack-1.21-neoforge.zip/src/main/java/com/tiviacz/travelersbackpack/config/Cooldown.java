package com.tiviacz.travelersbackpack.config;

public record Cooldown(int minCooldown, int maxCooldown) {
}