package com.tiviacz.travelersbackpack.client.screens.widgets;

import com.tiviacz.travelersbackpack.inventory.upgrades.Point;

public record WidgetElement(Point pos, Point size) {
}