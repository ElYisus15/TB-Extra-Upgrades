package com.tiviacz.travelersbackpack.compat.craftingtweaks;

public interface ICraftingTweaks { //#TODO
    void onCraftingSlotsHidden();

    void onCraftingSlotsDisplayed();

   /* void setScreen(TravelersBackpackScreen screen);

    ICraftingTweaks EMPTY = new ICraftingTweaks() {
        @Override
        public void onCraftingSlotsHidden() {
        }

        @Override
        public void onCraftingSlotsDisplayed() {
        }

        @Override
        public void setScreen(TravelersBackpackScreen screen) {
        }
    }; */
}
