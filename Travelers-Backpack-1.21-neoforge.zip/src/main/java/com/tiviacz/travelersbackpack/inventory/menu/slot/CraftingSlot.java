package com.tiviacz.travelersbackpack.inventory.menu.slot;

import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;

public class CraftingSlot extends Slot {
    public CraftingSlot(Container container, int slot, int x, int y) {
        super(container, slot, x, y);
    }
}