package com.tiviacz.travelersbackpack.inventory.upgrades;

public record Point(int x, int y) {
}
