✨ Added Item Tag support to Pickup Upgrade, Void Upgrade, and Magnet Upgrade  
🐛 Prevent crash when Package from Create is hit with Bee Backpack ability enabled  
🐛 Fixed item duplication issue related to the Crafting Upgrade  
🐛 Fixed occasional crash when using the Hose Item on a Cauldron  
🐛 Fixed reversed behavior when ignoring/matching item nbt data  
🐛 Fixed crash with Deep Aether  
📚 Updated pt_br, ru_ru, and zh_cn translations

⭐ Want to receive **Supporter Star Badge** for a **lifetime**? - [visit my Ko-Fi page](https://ko-fi.com/tiviacz1337)!  
![Banner](https://i.imgur.com/SSrFv58.png)